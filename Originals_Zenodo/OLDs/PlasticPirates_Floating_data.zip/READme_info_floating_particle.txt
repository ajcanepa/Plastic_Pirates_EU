
DOI: 10.5281/zenodo.14506687

Floating macro-, meso- and microlitter data collected by school children from the surface water of European rivers and streams in the period 2022-2024 for the Plastic Pirates – Go Europe! project. The data have been validated by experts. (Micro)litter particles have been analysed in the lab by experts to assess their characteristics. 
Acknowledgement: These data have been collected by numerous school schildren and their teachers from primary and secondary schools. We would like to thank all of them for their valuable contributions. 
The data files contain data on the amount of floating litter observed, the sampling effort and the characteristics (size, type, colour, material) of the (micro)litter particles. The data are collected in Austria, Belgium, Hungary, Portugal and Slovenia during the autumn 2022, spring 2023, autumn 2023 and spring 2024 sampling campaigns of the project. The sampling methods used can be found in the Plastic Pirates project booklet (methods for group C and D): https://www.plastic-pirates.eu/en/material/download.


Files:

READme_floating_particle: Explanation of the (meta)data fields in the data files Floating_data and Particle_data.
Floating_data: Metadata and results of groups C (floating macro-, meso- and microlitter) and D (reporter group; sources of waste and weather).
Particle_data: Results of the laboratory analysis of the particles collected with the net (group C). Assessing size, colour, type and polymer type of the particles.
ParticleAnalysisProtocol_Austria2022: Method particle analysis in the laboratory for Austria for the data collected in 2022.
ParticleAnalysisProtocol_Austria2023: Method particle analysis in the laboratory for Austria for the data collected in 2023.
ParticleAnalysisProtocol_Austria2024: Method particle analysis in the laboratory for Austria for the data collected in 2024.
Project_Booklet_EN: Plastic Pirates - Go Europe! Project Booklet


Remarks:

"na" or "NA" means "not applicable".
Data for river width and observed river width for group C could not always be verified by the experts.
Data of calculated flow velocity should be used with caution.


More information:

Methods data collection by citizens:
Plastic Pirates - Go Europe! Project Booklet (Group C and D) - https://www.plastic-pirates.eu/en/material/download
Deliverable D3.1 Plastic Pirates – Go Europe! common and harmonized standards to data sampling, processing, analysis and storage

Methods data verification by experts:
Deliverable D3.1 Plastic Pirates – Go Europe! common and harmonized standards to data sampling, processing, analysis and storage

